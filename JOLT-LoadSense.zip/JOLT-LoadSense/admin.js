jQuery(document).ready(function ($) {
    $('#jolt_upload_button').click(function (e) {
        e.preventDefault();
        let frame = wp.media({
            title: 'Select or Upload Preloader Image',
            button: {
                text: 'Use this image'
            },
            multiple: false
        });

        frame.on('select', function () {
            let attachment = frame.state().get('selection').first().toJSON();
            $('#jolt_preloader_image').val(attachment.url);
        });

        frame.open();
    });
});
